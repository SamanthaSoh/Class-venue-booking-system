package cvb_objects;

public class Department {

	private String departmentID, departmentName;

	public Department() {}

	public Department(String departmentID, String departmentName) {

		this.departmentID = departmentID;
		this.departmentName = departmentName;
	}

	//Setter methods
	public void setDepartmentID(String departmentID) {
		this.departmentID = departmentID;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	//Getter methods
	public String getDepartmentID() {
		return departmentID;
	}

	public String getDepartmentName() {
		return departmentName;
	}

}
