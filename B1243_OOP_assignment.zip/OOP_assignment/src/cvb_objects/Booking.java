package cvb_objects;

import java.time.LocalDate;
import java.time.LocalTime;

public class Booking {

	private String bookingID, staffID, venueID;
	private LocalDate date;
	private LocalTime timeIn, timeOut;

	public Booking() {}

	public Booking(String bookingID, LocalDate date, LocalTime timeIn, LocalTime timeOut, String staffID, String venueID) {

		this.bookingID = bookingID;
		this.date = date;
		this.timeIn = timeIn;
		this.timeOut = timeOut;
		this.staffID = staffID;
		this.venueID = venueID;
	}

	//Setter methods
	public void setBookingID(String bookingID) {
		this.bookingID = bookingID;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public void setTimeIn(LocalTime timeIn) {
		this.timeIn = timeIn;
	}

	public void setTimeOut(LocalTime timeOut) {
		this.timeOut = timeOut;
	}

	public void setStaffID(String staffID) {
		this.staffID = staffID;
	}

	public void setVenueID(String venueID) {
		this.venueID = venueID;
	}

	//Getter methods
	public String getBookingID() {
		return bookingID;
	}

	public LocalDate getDate() {
		return date;
	}

	public LocalTime getTimeIn() {
		return timeIn;
	}

	public LocalTime getTimeOut() {
		return timeOut;
	}

	public String getStaffID() {
		return staffID;
	}

	public String getVenueID() {
		return venueID;
	}

}
