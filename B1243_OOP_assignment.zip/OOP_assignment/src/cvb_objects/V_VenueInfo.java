package cvb_objects;

public class V_VenueInfo {

	private String venueID, venueName, capacity, venueTypeID, venueType;

	public V_VenueInfo() {}

	public  V_VenueInfo(String venueID, String venueName, String capacity, String venueTypeID, String venueType) {
		this.venueID = venueID;
		this.venueName = venueName;
		this.capacity = capacity;
		this.venueTypeID = venueTypeID;
		this.venueType = venueType;
	}

	public String getVenueID() {
		return venueID;
	}

	public String getVenueName() {
		return venueName;
	}

	public String getCapacity() {
		return capacity;
	}

	public String getVenueTypeID() {
		return venueTypeID;
	}

	public String getVenueType() {
		return venueType;
	}

}
