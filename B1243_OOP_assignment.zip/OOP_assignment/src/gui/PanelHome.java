package gui;

import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class PanelHome extends JPanel {

	private Image img_logo = new ImageIcon(Login.class.getResource("/college.png")).getImage().getScaledInstance(150,150,Image.SCALE_SMOOTH);

	public PanelHome() {

		setBounds(0, 0, 454,396);
		setLayout(null);
		setVisible(true);

		JLabel lblHomeIntro = new JLabel("Welcome to Apollo University College");
		lblHomeIntro.setHorizontalAlignment(SwingConstants.CENTER);
		lblHomeIntro.setFont(new Font("Arial", Font.BOLD, 20));
		lblHomeIntro.setBounds(44, 46, 361, 36);
		add(lblHomeIntro);

		JLabel lblHomeIntro2 = new JLabel("Class Venue Booking Portal");
		lblHomeIntro2.setHorizontalAlignment(SwingConstants.CENTER);
		lblHomeIntro2.setFont(new Font("Arial", Font.BOLD, 15));
		lblHomeIntro2.setBounds(44, 73, 361, 36);
		add(lblHomeIntro2);

		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setBounds(93, 120, 270, 193);
		lblLogo.setIcon(new ImageIcon(img_logo));
		add(lblLogo);

		JLabel lblHomeIntroEnq = new JLabel("For any enquiries, please contact: +603-3232 2323");
		lblHomeIntroEnq.setHorizontalAlignment(SwingConstants.CENTER);
		lblHomeIntroEnq.setFont(new Font("Arial", Font.BOLD, 10));
		lblHomeIntroEnq.setBounds(44, 306, 361, 36);
		add(lblHomeIntroEnq);

		JLabel lblHomeIntroEnq2 = new JLabel("E-mail: all.itcentre@auc.edu.my");
		lblHomeIntroEnq2.setHorizontalAlignment(SwingConstants.CENTER);
		lblHomeIntroEnq2.setFont(new Font("Arial", Font.BOLD, 10));
		lblHomeIntroEnq2.setBounds(0, 324, 361, 36);
		add(lblHomeIntroEnq2);

	}
}
