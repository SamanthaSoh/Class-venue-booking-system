package cvb_objects;

public class Staff {

	private String staffID, staffName, password, phoneNum, departmentID, jobTitleID;

	public Staff() {}

	public Staff(String staffID, String staffName, String password, String phoneNum, String departmentID, String jobTitleID) {

		this.staffID = staffID;
		this.staffName = staffName;
		this.password = password;
		this.phoneNum = phoneNum;
		this.departmentID = departmentID;
		this.jobTitleID = jobTitleID;
	}

	//Setter methods
	public void setStaffID(String staffID) {
		this.staffID = staffID;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}

	public void setPassword(String password) {
		this. password =  password;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public void setDepartmentID(String departmentID) {
		this.departmentID = departmentID;
	}

	public void setJobTitleID(String jobTitleID) {
		this.jobTitleID = jobTitleID;
	}

	//Getter methods
	public String getStaffID() {
		return staffID;
	}

	public String getStaffName() {
		return staffName;
	}

	public String getPassword() {
		return password;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public String getDepartmentID() {
		return departmentID;
	}

	public String getJobTitleID() {
		return jobTitleID;
	}

}
