package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.LineBorder;

import cvb_objects.Staff;
import database.AccessDatabase;
import database.ConnectDatabase;
import utils.UserUtils;

public class Login extends AccessDatabase {

	static Staff staff;
	public JFrame loginFrame;
	private JPanel contentPane;

	private ImageIcon bg_img = new ImageIcon(Login.class.getResource("/apollo.jpg"));
	private Image img_logo = new ImageIcon(Login.class.getResource("/college.png")).getImage().getScaledInstance(90,90,Image.SCALE_SMOOTH);
	private Image img_staffID = new ImageIcon(Login.class.getResource("/profile.png")).getImage().getScaledInstance(35,35,Image.SCALE_SMOOTH);
	private Image img_password = new ImageIcon(Login.class.getResource("/pwd.png")).getImage().getScaledInstance(30,30,Image.SCALE_SMOOTH);

	private JTextField txtStaffID;
	private JPasswordField txtPassword;

	public Login() throws Exception {
		
		loginFrame = new JFrame();
		loginFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		loginFrame.setBounds(300, 300, 676, 418);
		loginFrame.setUndecorated(true);
		loginFrame.setLocationRelativeTo(null);

		contentPane = new JPanel() {
			@Override
			public void paintComponent(Graphics g) {
	            super.paintComponent(g);
	            Image img = bg_img.getImage();
	            g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
	         }
		};
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		loginFrame.setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setBounds(269, 52, 142, 99);
		lblLogo.setIcon(new ImageIcon(img_logo));
		contentPane.add(lblLogo);

		JPanel panelStaffID = new JPanel();
		panelStaffID.setBackground(new Color(255, 255, 255));
		panelStaffID.setBounds(211, 181, 250, 40);
		contentPane.add(panelStaffID);
		panelStaffID.setLayout(null);

		txtStaffID = new JTextField();
		txtStaffID.addFocusListener(new FocusAdapter(){
			@Override
			public void focusGained(FocusEvent e) {
				if(txtStaffID.getText().equals("Staff ID")) {
					txtStaffID.setText("");
				}
				else {
					txtStaffID.selectAll();
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(txtStaffID.getText().equals("")) {
					txtStaffID.setText("Staff ID");
				}
				else {
					txtStaffID.selectAll();
				}
			}
		});
		txtStaffID.setBorder(null);
		txtStaffID.setBackground(new Color(255, 255, 255));
		txtStaffID.setFont(new Font("Arial", Font.PLAIN, 12));
		txtStaffID.setText("Staff ID");
		txtStaffID.setBounds(10, 11, 170, 20);
		panelStaffID.add(txtStaffID);
		txtStaffID.setColumns(10);

		JLabel lblStaffIDIcon = new JLabel("");
		lblStaffIDIcon.setHorizontalAlignment(SwingConstants.CENTER);
		lblStaffIDIcon.setBounds(206, 0, 44, 40);
		lblStaffIDIcon.setIcon(new ImageIcon(img_staffID));
		panelStaffID.add(lblStaffIDIcon);

		JPanel panelPassword = new JPanel();
		panelPassword.setBackground(new Color(255, 255, 255));
		panelPassword.setBounds(211, 232, 250, 40);
		contentPane.add(panelPassword);
		panelPassword.setLayout(null);

		txtPassword = new JPasswordField();
		txtPassword.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(txtPassword.getText().equals("Password")){
					txtPassword.setEchoChar('\u25CF');
					txtPassword.setText("");
				}
				else {
					txtPassword.selectAll();
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(txtPassword.getText().equals("")) {
					txtPassword.setText("Password");
					txtPassword.setEchoChar((char)0);
				}
			}
		});
		txtPassword.setBorder(null);
		txtPassword.setBackground(new Color(255, 255, 255));
		txtPassword.setEchoChar((char)0);
		txtPassword.setFont(new Font("Arial", Font.PLAIN, 12));
		txtPassword.setText("Password");
		txtPassword.setBounds(10, 11, 170, 20);
		panelPassword.add(txtPassword);

		JLabel lblPasswordIcon = new JLabel("");
		lblPasswordIcon.setHorizontalAlignment(SwingConstants.CENTER);
		lblPasswordIcon.setBounds(204, 0, 46, 40);
		lblPasswordIcon.setIcon(new ImageIcon(img_password));
		panelPassword.add(lblPasswordIcon);

		//Exit label
		JLabel lblExit = new JLabel("X");
		lblExit.setForeground(Color.WHITE);
		lblExit.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
		lblExit.setHorizontalAlignment(SwingConstants.CENTER);
		lblExit.setBounds(646,11,20,20);
		lblExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				closeProgram();
				loginFrame.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblExit.setForeground(Color.RED);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblExit.setForeground(Color.WHITE);
			}
		});
		contentPane.add(lblExit);

		JPanel panelBtnLogin = new JPanel();
		panelBtnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (txtStaffID.getText().isBlank()) {
					JOptionPane.showMessageDialog(new JFrame(), "No staff ID entered", "Empty field", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if (txtPassword.getPassword().length == 0) {
					JOptionPane.showMessageDialog(new JFrame(), "No password entered", "Empty field", JOptionPane.WARNING_MESSAGE);
					return;
				}

				//Check if entered staff ID and password is same as in database
				try {
					Staff selectedStaff = null;
					ArrayList<Staff> staffs = getAllStaff();
					for (Staff staff2 : staffs) {
						String DBStaffID = staff2.getStaffID();
						String userIDInput = txtStaffID.getText();

						char[] DBStaffPassword = staff2.getPassword().toCharArray();
						char[] userPwdInput = txtPassword.getPassword();

						if (DBStaffID.equals(userIDInput) && Arrays.equals(DBStaffPassword,userPwdInput)) {
							selectedStaff = staff2;
							break;
						}
					}
					//if not empty
					if (selectedStaff != null) {
						System.out.println("Log in successful");
						UserUtils.setStaffID(txtStaffID.getText()); //set global staff ID
						Menu menu = new Menu();
						menu.setUserView(selectedStaff);
						menu.setVisible(true);
						loginFrame.dispose();
					}
					else {
						JOptionPane.showMessageDialog(new JFrame(), "Incorrect Staff ID or Password", "Incorrect login credentials", JOptionPane.WARNING_MESSAGE);
						return;
					}
				} catch (Exception e1) {
					String msg = e1.getMessage();
					if (msg.isEmpty()) {
						JOptionPane.showMessageDialog(new JFrame(), "Something is null, check database connection");
					}
					else {
						JOptionPane.showMessageDialog(new JFrame(), e1.getMessage());
					}
					e1.printStackTrace();
				}
			}
		});
		panelBtnLogin.setBackground(new Color(119, 136, 153));
		panelBtnLogin.setBounds(211, 304, 250, 47);
		contentPane.add(panelBtnLogin);
		panelBtnLogin.setLayout(null);

		JLabel lblLogin = new JLabel("LOG IN");
		lblLogin.setBounds(102, 11, 61, 25);
		lblLogin.setForeground(new Color(255, 255, 255));
		lblLogin.setFont(new Font("Arial", Font.BOLD, 14));
		panelBtnLogin.add(lblLogin);

	}

	int closeProgram() {
		int exit = JOptionPane.showConfirmDialog(null, "Are you sure you want to close this application?", "Confirmation", JOptionPane.YES_NO_OPTION);
		if (exit == JOptionPane.YES_OPTION) {
			close();
			ConnectDatabase.close();
			System.out.println("Database connection is closed");
			System.exit(0);
		}
		else {
			System.exit(1);
		}
		return 0;
	}
}
