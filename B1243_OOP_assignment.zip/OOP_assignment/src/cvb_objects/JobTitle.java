package cvb_objects;

public class JobTitle {

	private String jobTitleID, jobTitle;

	public JobTitle() {}

	public JobTitle(String jobTitleID, String jobTitle) {

		this.jobTitleID = jobTitleID;
		this.jobTitle = jobTitle;
	}

	//Setter methods
	public void setJobTitleID(String jobTitleID) {
		this.jobTitleID = jobTitleID;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	//Getter methods
	public String getJobTitleID() {
		return jobTitleID;
	}

	public String getJobTitle() {
		return jobTitle;
	}

}
