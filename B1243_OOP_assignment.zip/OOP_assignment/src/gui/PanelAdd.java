package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import com.github.lgooddatepicker.components.DatePicker;
import com.github.lgooddatepicker.components.DatePickerSettings;
import com.github.lgooddatepicker.components.TimePicker;
import com.github.lgooddatepicker.components.TimePickerSettings;
import com.github.lgooddatepicker.optionalusertools.DateChangeListener;
import com.github.lgooddatepicker.optionalusertools.PickerUtilities;
import com.github.lgooddatepicker.optionalusertools.TimeChangeListener;
import com.github.lgooddatepicker.optionalusertools.TimeVetoPolicy;
import com.github.lgooddatepicker.zinternaltools.DateChangeEvent;
import com.github.lgooddatepicker.zinternaltools.TimeChangeEvent;

import cvb_objects.Booking;
import cvb_objects.EngineeringLab;
import cvb_objects.ITLab;
import cvb_objects.LectureHall;
import cvb_objects.V_StaffBooking;
import cvb_objects.VenueType;
import database.AccessDatabase;
import utils.UserUtils;

public class PanelAdd extends AccessDatabase {
	
	JPanel panelAdd;
	private SimpleDateFormat dateFormat;
	private Date selectedDate;
	private String bookingID, staffID, venueID;
	private LectureHall lecHall;
	private EngineeringLab engLab;
	private ITLab itLab;
	private LocalDate date;
	final LocalDate today = LocalDate.now();
	private LocalTime timeIn, timeOut;
	private static JTable tblBookingInfo;

	@SuppressWarnings("unchecked")
	public PanelAdd() throws Exception {
		
		panelAdd = new JPanel();
		panelAdd.setBounds(0, 0, 454, 396);
		panelAdd.setLayout(null);
		panelAdd.setVisible(true);

		// Title of panel
		JLabel lblPanelAdd = new JLabel("ADD BOOKING");
		lblPanelAdd.setFont(new Font("Arial", Font.BOLD, 16));
		lblPanelAdd.setBounds(10, 11, 434, 36);
		panelAdd.add(lblPanelAdd);

		JButton btnViewTaken = new JButton("View class venues that are taken");
		btnViewTaken.setBackground(new Color(153, 153, 204));
		btnViewTaken.setBorder(new LineBorder(new Color(0, 0, 0)));
		btnViewTaken.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					showBooking();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnViewTaken.setFont(new Font("Arial", Font.PLAIN, 14));
		btnViewTaken.setBounds(10, 58, 419, 25);
		panelAdd.add(btnViewTaken);

		//Get lecture halls
		Object [] lectureHalls = getAllLectureHall().toArray();
		JComboBox comboBoxLH = new JComboBox(new DefaultComboBoxModel(lectureHalls));
		comboBoxLH.setRenderer(new DefaultListCellRenderer() {
			@Override
			public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
					boolean cellHasFocus) {
				super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
				//value is an instance/object of LectureHall class
				if (value instanceof LectureHall) {
					LectureHall lh = (LectureHall) value;
					setText(lh.getVenueName());
				}
				return this;
			}
		});
		//To get the venue id when the venue is selected
		comboBoxLH.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == comboBoxLH) {
					lecHall = (LectureHall) comboBoxLH.getSelectedItem();
					venueID = lecHall.getVenueID();
				}
			}
		});
		comboBoxLH.setPreferredSize(new Dimension(450, 30));
		comboBoxLH.setBounds(104, 150, 131, 25);

		//Get engineering halls
		Object [] engineeringLabs = getAllEngLab().toArray();
		JComboBox comboBoxEL = new JComboBox(new DefaultComboBoxModel(engineeringLabs));
		 comboBoxEL.setRenderer(new DefaultListCellRenderer() {
			@Override
			public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
					boolean cellHasFocus) {
				super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
				if (value instanceof EngineeringLab) {
					EngineeringLab el = (EngineeringLab) value;
					setText(el.getVenueName());
				}
				return this;
			}
		});
		comboBoxEL.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() ==  comboBoxEL) {
					engLab = (EngineeringLab)  comboBoxEL.getSelectedItem();
					venueID = engLab.getVenueID();
				}
			}
		});
		comboBoxEL.setPreferredSize(new Dimension(450, 30));
		comboBoxEL.setBounds(104, 150, 131, 25);

		//Get IT labs
		Object [] itLabs = getAllITLab().toArray();
		JComboBox comboBoxIL = new JComboBox(new DefaultComboBoxModel(itLabs));
		comboBoxIL.setRenderer(new DefaultListCellRenderer() {
			@Override
			public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
					boolean cellHasFocus) {
				super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
				if (value instanceof ITLab) {
					ITLab il = (ITLab) value;
					setText(il.getVenueName());
				}
				return this;
			}
		});
		comboBoxIL.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() ==  comboBoxIL) {
					itLab = (ITLab)  comboBoxIL.getSelectedItem();
					venueID = itLab.getVenueID();
				}
			}
		});
		comboBoxIL.setPreferredSize(new Dimension(450, 30));
		comboBoxIL.setBounds(104, 150, 131, 25);

		// Venue type
		JLabel lblVenue = new JLabel("Type:");
		lblVenue.setFont(new Font("Arial", Font.PLAIN, 14));
		lblVenue.setBounds(10, 111, 84, 21);
		panelAdd.add(lblVenue);

		// venues
		JLabel lblClassVenue = new JLabel("Class venue:");
		lblClassVenue.setFont(new Font("Arial", Font.PLAIN, 14));
		lblClassVenue.setBounds(10, 150, 84, 25);
		panelAdd.add(lblClassVenue);

		ArrayList<VenueType> VToptions = getAllVenueTypes();
		Vector<String> venueType = new Vector<>();
		venueType.add("Select venue type..");
		for (VenueType vToption : VToptions) {
			venueType.add(vToption.getVenueType()); //To get the venue type name
		}

		JComboBox<String> comboBoxVT = new JComboBox<>(venueType);
		comboBoxVT.setPreferredSize(new Dimension(450, 30));
		comboBoxVT.setBounds(104, 110, 131, 25);
		comboBoxVT.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String selectedVenueType = comboBoxVT.getSelectedItem().toString();
				if (selectedVenueType == comboBoxVT.getItemAt(1)) {
					comboBoxEL.setVisible(false);
					comboBoxIL.setVisible(false);
					panelAdd.add(comboBoxLH);
					comboBoxLH.setVisible(true);
					return;
				}
				if (selectedVenueType == comboBoxVT.getItemAt(2)) {
					comboBoxLH.setVisible(false);
					comboBoxIL.setVisible(false);
					panelAdd.add(comboBoxEL);
					comboBoxEL.setVisible(true);
					return;
				}
				if (selectedVenueType == comboBoxVT.getItemAt(3)) {
					comboBoxLH.setVisible(false);
					comboBoxEL.setVisible(false);
					panelAdd.add(comboBoxIL);
					comboBoxIL.setVisible(true);
					return;
				}
			}
		});
		panelAdd.add(comboBoxVT);

		//Date
		JLabel lblDate = new JLabel("Date:");
		lblDate.setFont(new Font("Arial", Font.PLAIN, 14));
		lblDate.setBounds(10, 194, 84, 25);
		panelAdd.add(lblDate);

		DatePickerSettings dateSettings = new DatePickerSettings();
		DatePicker datePicker = new DatePicker(dateSettings);
		dateSettings.setAllowEmptyDates(false);
		dateSettings.setDateRangeLimits(today.minusDays(0), today.plusDays(7));
		datePicker.getComponentToggleCalendarButton().setBounds(157, 0, 27, 25);
		datePicker.getComponentDateTextField().setBounds(0, 0, 158, 25);
		datePicker.setBounds(104, 195, 186, 25);
		datePicker.setDateToToday();
		datePicker.addDateChangeListener(new DateChangeListener() {
			@Override
			public void dateChanged(DateChangeEvent arg0) {
				if (arg0.getSource() == datePicker) {
					date = datePicker.getDate();
				}
			}
		});
		panelAdd.add(datePicker);
		datePicker.setLayout(null);

		JLabel lblTimeIn = new JLabel("Time in:");
		lblTimeIn.setFont(new Font("Arial", Font.PLAIN, 14));
		lblTimeIn.setBounds(10, 240, 84, 25);
		panelAdd.add(lblTimeIn);

		//Time in
		TimePickerSettings timeSettings = new TimePickerSettings();
		TimePicker timeInPicker = new TimePicker(timeSettings);
		timeSettings.setVetoPolicy(new setTimeRange());
		timeInPicker.setBounds(104, 240, 131, 25);
		timeInPicker.addTimeChangeListener(new TimeChangeListener() {
			@Override
			public void timeChanged(TimeChangeEvent arg0) {
				if (arg0.getSource() == timeInPicker) {
					timeIn = timeInPicker.getTime();
				}
			}
		});
		panelAdd.add(timeInPicker);

		//Time out
		JLabel lblTimeOut = new JLabel("Time out:");
		lblTimeOut.setFont(new Font("Arial", Font.PLAIN, 14));
		lblTimeOut.setBounds(10, 290, 84, 25);
		panelAdd.add(lblTimeOut);

		TimePicker timeOutPicker = new TimePicker(timeSettings);
		timeOutPicker.getComponentSpinnerPanel().setBounds(131, 0, 0, 25);
		timeOutPicker.getComponentToggleTimeMenuButton().setBounds(105, 0, 26, 25);
		timeOutPicker.getComponentTimeTextField().setBounds(0, 0, 105, 25);
		timeOutPicker.setBounds(104, 290, 131, 25);
		timeOutPicker.addTimeChangeListener(new TimeChangeListener() {
			@Override
			public void timeChanged(TimeChangeEvent arg0) {
				if (arg0.getSource() == timeOutPicker) {
					timeOut = timeOutPicker.getTime();
				}
			}

		});
		panelAdd.add(timeOutPicker);
		timeOutPicker.setLayout(null);

		//Button 'book'
		JButton btnBook = new JButton("Book");
		btnBook.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//To set the bookingID
				String bID = "";
				try {
					Booking lastBooking = getLastBooking();
					if (lastBooking.getBookingID() == null) {
						bID = "B000";
					} else {
						bID = lastBooking.getBookingID();
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				String lastB_ID = bID.substring(1, 4);
				int ID = Integer.parseInt(lastB_ID) + 1;
				lastB_ID = String.valueOf(ID);

				if (lastB_ID.length() < 2) {
					bookingID = "B00" + lastB_ID;
				} else if (lastB_ID.length() < 3) {
					bookingID = "B0" + lastB_ID;
				} else {
					bookingID = "B" + lastB_ID;
				}

				try {
					LocalDate DbDate = null;
					LocalTime DbTimeIn = null, DbTimeOut = null;
					boolean isSame = false;

					ArrayList<V_StaffBooking> bookings = getStaffBooking();

					//Get a list of bookings from selected venue
					List <V_StaffBooking> sameVenueBookings = bookings.stream().filter(b -> b.getVenueID().equals(venueID)).collect(Collectors.toList());

					//Get a list of bookings from selected date
					List <V_StaffBooking> sameDateBookings = sameVenueBookings.stream().filter(b -> b.getDate().equals(date)).collect(Collectors.toList());

					//If same date booking is found
					if(sameDateBookings.size() > 0) {
						//Check if time available on selected date
						for (V_StaffBooking sameDateBooking : sameDateBookings) {
							DbTimeIn = sameDateBooking.getTimeIn();
							DbTimeOut = sameDateBooking.getTimeOut();

							if (DbTimeIn.equals(timeIn) && DbTimeOut.equals(timeOut)) {
								JOptionPane.showMessageDialog(new JFrame(), "Unsuccessful booking. \nDate and time slot is taken.","Unsuccessful booking", JOptionPane.WARNING_MESSAGE);
								break;
							}
							else if((DbTimeIn.equals(timeIn) || timeIn.isAfter(DbTimeIn)) && (DbTimeOut.equals(timeOut) || timeOut.isBefore(DbTimeOut)) ) {
								JOptionPane.showMessageDialog(new JFrame(), "Unsuccessful booking. \nDate and time slot is taken.");
								break;
							}
							else {
								//insert data to booking table
								Booking booking = new Booking(bookingID, date, timeIn, timeOut, UserUtils.getStaffID(), venueID);
								String error = insertOneBooking(booking);
								if (!error.isEmpty()) {
									JOptionPane.showMessageDialog(new JFrame(), "Error : " + error, "Fail to add booking", JOptionPane.ERROR_MESSAGE);
								}else {
									JOptionPane.showMessageDialog(new JFrame(), "Booking successful.");
								}
							}
						}
					}
					else {
						//insert data to booking table
						Booking booking = new Booking(bookingID, date, timeIn, timeOut, UserUtils.getStaffID(), venueID);
						String error = insertOneBooking(booking);
						if (!error.isEmpty()) {
							JOptionPane.showMessageDialog(new JFrame(), "Error : " + error + "\nContact system admin",
									"Data insertion error", JOptionPane.ERROR_MESSAGE);
						}else {
							JOptionPane.showMessageDialog(new JFrame(), "Booking successful.");
						}
					}
				} catch (Exception e1) {
					String msg = e1.getMessage();
					if (msg.isEmpty()) {
						JOptionPane.showMessageDialog(new JFrame(), "Something is null, check database connection");
					}
					else {
						JOptionPane.showMessageDialog(new JFrame(), e1.getMessage());
					}
					e1.printStackTrace();
				}
			}
		});
		btnBook.setFont(new Font("Arial", Font.PLAIN, 14));
		btnBook.setBounds(340, 345, 89, 25);
		panelAdd.add(btnBook);

		tblBookingInfo = new JTable();

	}

	private static class setTimeRange implements TimeVetoPolicy {
		//isTimeAllowed, Return true if a time should be allowed, or false if a time should be vetoed
        @Override
        public boolean isTimeAllowed(LocalTime time) {
            // Only allow times from 9a to 5p, inclusive.
            return PickerUtilities.isLocalTimeInRange(
                time, LocalTime.of(9, 00), LocalTime.of(17, 00), true);
        }
    }

	static void showBooking() throws Exception {

		String[] columnBooking = { "Date", "Time in", "Time out", "Venue Name" };
		DefaultTableModel bookingTableModel = new DefaultTableModel(columnBooking, 0);

		ArrayList<V_StaffBooking> booking;
		try {
			booking = getStaffBooking();

			for (V_StaffBooking element : booking) {
				LocalDate date = element.getDate();
				LocalTime timeIn = element.getTimeIn();
				LocalTime timeOut = element.getTimeOut();
				String venueName = element.getVenueName();

				String[] dataBooking = {date.toString(), timeIn.toString(), timeOut.toString(), venueName};
				bookingTableModel.addRow(dataBooking);
				tblBookingInfo.setModel(bookingTableModel);
				tblBookingInfo.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
			}

			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(10, 46, 382, 172);
			scrollPane.setViewportView(tblBookingInfo);
		    JOptionPane.showMessageDialog(new JFrame(), scrollPane,"Booked class venues", JOptionPane.PLAIN_MESSAGE);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
