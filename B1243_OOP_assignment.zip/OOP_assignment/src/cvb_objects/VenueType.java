package cvb_objects;

public class VenueType {

	private String venueTypeID, venueType;

	public VenueType() {}

	public VenueType(String venueTypeID, String venueType) {
		this.venueTypeID = venueTypeID;
		this.venueType = venueType;
	}

	//Setter methods
	public void setVenueTypeID(String venueTypeID) {
		this.venueTypeID = venueTypeID;
	}

	public void setVenueType(String venueType) {
		this.venueType = venueType;
	}

	//Getter methods
	public String getVenueTypeID() {
		return venueTypeID;
	}

	public String getVenueType() {
		return venueType;
	}
}
