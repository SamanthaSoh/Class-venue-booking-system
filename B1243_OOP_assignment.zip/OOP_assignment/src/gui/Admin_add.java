package gui;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cvb_objects.LectureHall;
import database.AccessDatabase;


public class Admin_add extends AccessDatabase {
	
	JPanel panelAdminAdd;
	private JTextField txtVenueID;
	private JTextField txtVenueName;
	private JTextField txtCapacity;
	private JTextField txtVenueTypeID;
	String error;

	public Admin_add() {
		
		panelAdminAdd = new JPanel();
		panelAdminAdd.setBounds(0,0, 454,396);
		panelAdminAdd.setLayout(null);

		JLabel lblPanelAdd = new JLabel("Add venue");
		lblPanelAdd.setFont(new Font("Arial", Font.BOLD, 14));
		lblPanelAdd.setBounds(10, 11, 361, 36);
		panelAdminAdd.add(lblPanelAdd);

		//Venue Details
		JLabel lblVenueID = new JLabel("Venue ID : ");
		lblVenueID.setFont(new Font("Arial", Font.PLAIN, 14));
		lblVenueID.setBounds(10, 58, 70, 28);
		panelAdminAdd.add(lblVenueID);

		JLabel lblVenueName = new JLabel("Venue name : ");
		lblVenueName.setFont(new Font("Arial", Font.PLAIN, 14));
		lblVenueName.setBounds(10, 109, 97, 28);
		panelAdminAdd.add(lblVenueName);

		JLabel lblCapacity = new JLabel("Capacity : ");
		lblCapacity.setFont(new Font("Arial", Font.PLAIN, 14));
		lblCapacity.setBounds(10, 162, 70, 28);
		panelAdminAdd.add(lblCapacity);

		JLabel lblVenueTypeID = new JLabel("Venue type ID : ");
		lblVenueTypeID.setFont(new Font("Arial", Font.PLAIN, 14));
		lblVenueTypeID.setBounds(10, 214, 109, 28);
		panelAdminAdd.add(lblVenueTypeID);

		txtVenueID = new JTextField();
		txtVenueID.setBounds(117, 58, 142, 28);
		panelAdminAdd.add(txtVenueID);
		txtVenueID.setColumns(10);

		txtVenueName = new JTextField();
		txtVenueName.setColumns(10);
		txtVenueName.setBounds(117, 110, 142, 28);
		panelAdminAdd.add(txtVenueName);

		txtCapacity = new JTextField();
		txtCapacity.setColumns(10);
		txtCapacity.setBounds(117, 163, 142, 28);
		panelAdminAdd.add(txtCapacity);

		txtVenueTypeID = new JTextField();
		txtVenueTypeID.setColumns(10);
		txtVenueTypeID.setBounds(117, 214, 142, 28);
		panelAdminAdd.add(txtVenueTypeID);

		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (txtVenueID.getText().isEmpty()) {
					JOptionPane.showMessageDialog(new JFrame(), "Venue ID textfield is empty", "Empty field", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if (txtVenueName.getText().isEmpty()) {
					JOptionPane.showMessageDialog(new JFrame(), "Venue name textfield is empty", "Empty field", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if (txtCapacity.getText().isEmpty()) {
					JOptionPane.showMessageDialog(new JFrame(), "Capacity textfield is empty", "Empty field", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if (txtVenueTypeID.getText().isEmpty()) {
					JOptionPane.showMessageDialog(new JFrame(), "Venue type ID textfield is empty", "Empty field", JOptionPane.WARNING_MESSAGE);
					return;
				}

				//Only calling LectureHall class because it has the same columns as EngineeringLab and ITLab class
				LectureHall lh = new LectureHall (txtVenueID.getText(), txtVenueName.getText(), txtCapacity.getText(), txtVenueTypeID.getText());
				error = insertOneVenue(lh);

				if (!error.isEmpty()) {
					JOptionPane.showMessageDialog(new JFrame(), "Error : " + error + "\nContact system admin", "Fail to add venue", JOptionPane.ERROR_MESSAGE);
					return;
				}

				txtVenueID.setText("");
				txtVenueName.setText("");
				txtCapacity.setText("");
				txtVenueTypeID.setText("");
				JOptionPane.showMessageDialog(new JFrame(), "Venue successfully added.", "Venue added successfully", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnAdd.setFont(new Font("Arial", Font.PLAIN, 14));
		btnAdd.setBounds(322, 312, 89, 36);
		panelAdminAdd.add(btnAdd);
	}
}
