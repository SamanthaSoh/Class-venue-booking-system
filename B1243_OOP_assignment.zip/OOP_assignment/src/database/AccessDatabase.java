package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import cvb_objects.Booking;
import cvb_objects.EngineeringLab;
import cvb_objects.ITLab;
import cvb_objects.LectureHall;
import cvb_objects.Staff;
import cvb_objects.V_StaffBooking;
import cvb_objects.V_VenueInfo;
import cvb_objects.VenueType;

public class AccessDatabase extends ConnectDatabase{

	private static Connection connect;
	private static Statement statement;
	private static ResultSet results;
	private static PreparedStatement preparedStatement;

	public AccessDatabase() {
		connect = getConnection();
		statement = getStatement();
		results = getResults();
	}

	//select all values from table in database
	//To  get all booking records
	public static ArrayList<V_StaffBooking> getStaffBooking() throws Exception{

		try {
			ArrayList<V_StaffBooking> booked = new ArrayList<>();
			results = statement.executeQuery("select * from v_staffbooking");
			while (results.next()) {
				V_StaffBooking b = new V_StaffBooking (results.getString("bookingID"), results.getString("staffID"), results.getObject(3,LocalDate.class), results.getObject(4, LocalTime.class),
						results.getObject(5, LocalTime.class), results.getString("venueID"), results.getString("venueName"));
				booked.add(b);
			}
			results.close();
			return booked;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	//To get the last booking ID
	public static Booking getLastBooking() throws Exception{

		try {
			Booking b = new Booking();
			results = statement.executeQuery("SELECT * FROM booking ORDER BY bookingID DESC LIMIT 1");
			while (results.next()) {
				b = new Booking (results.getString("bookingID"), results.getObject(2,LocalDate.class), results.getObject(3, LocalTime.class), results.getObject(4, LocalTime.class), results.getString("staffID"), results.getString("venueID"));
			}
			results.close();
			return b;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	//To get booking records according to staff ID
	public static ArrayList<V_StaffBooking> getStaffBooking (String staffID) throws Exception {

		try {
			ArrayList<V_StaffBooking> s_bookings = new ArrayList<>();
			results = statement.executeQuery("select * from v_staffbooking where staffID = '" + staffID + "'");
			System.out.println("Get "+ staffID +" booking successful");
			while(results.next()) {
				V_StaffBooking b = new V_StaffBooking(results.getString("bookingID"), results.getString("staffID"), results.getObject(3,LocalDate.class), results.getObject(4, LocalTime.class),
						results.getObject(5, LocalTime.class), results.getString("venueID"), results.getString("venueName"));
				s_bookings.add(b);
			}
			return s_bookings;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	//To get all venue types
	public static ArrayList<VenueType> getAllVenueTypes() throws Exception{

		try {
			ArrayList<VenueType> venueTypes = new ArrayList<>();
			results = statement.executeQuery("select * from venueType");
			while (results.next()) {
				VenueType vt = new VenueType(results.getString("venueTypeID"), results.getString("venueType"));
				venueTypes.add(vt);
			}
			results.close();
			return venueTypes;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	//To get all venues with venue type name
	public static ArrayList<V_VenueInfo> getAllVenues() throws Exception{

		try {
			ArrayList<V_VenueInfo> venue = new ArrayList<>();
			results = statement.executeQuery("select * from v_venueinfo");
			while (results.next()) {
				V_VenueInfo v = new V_VenueInfo (results.getString("venueID"), results.getString("venueName"), results.getString("capacity"),  results.getString("venueTypeID"), results.getString("venueType"));
				venue.add(v);
			}
			results.close();
			return venue;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	//To get all staffs
	public static ArrayList<Staff> getAllStaff() throws Exception{

		try {
			ArrayList<Staff> staffs = new ArrayList<>();
			results = statement.executeQuery("select * from staff");
			while (results.next()) {
				Staff s = new Staff(results.getString("staffID"), results.getString("staffName"), results.getString("password"), results.getString("phoneNum"),results.getString("departmentID"), results.getString("jobTitleID"));
				staffs.add(s);
			}
			results.close();
			return staffs;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	//To get all Lecture halls
	public static ArrayList<LectureHall> getAllLectureHall() throws Exception{

		try {
			ArrayList<LectureHall> lectureHalls = new ArrayList<>();
			results = statement.executeQuery("select * from venue where venueTypeID = 'VT001'");
			while (results.next()) {
				LectureHall lh = new LectureHall(results.getString("venueID"), results.getString("venueName"), results.getString("capacity"), results.getString("venueTypeID"));
				lectureHalls.add(lh);
			}
			results.close();
			return lectureHalls;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	//To get all Engineering labs
	public static ArrayList<EngineeringLab> getAllEngLab() throws Exception{

		try {
			ArrayList<EngineeringLab> engineeringLabs = new ArrayList<>();
			results = statement.executeQuery("select * from venue where venueTypeID = 'VT002'");
			while (results.next()) {
				EngineeringLab el = new EngineeringLab(results.getString("venueID"), results.getString("venueName"), results.getString("capacity"), results.getString("venueTypeID"));
				engineeringLabs.add(el);
			}
			results.close();
			return engineeringLabs;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	//To get all IT labs
	public static ArrayList<ITLab> getAllITLab() throws Exception{

		try {
			ArrayList<ITLab> itLabs = new ArrayList<>();
			results = statement.executeQuery("select * from venue where venueTypeID = 'VT003'");
			while (results.next()) {
				ITLab il = new ITLab(results.getString("venueID"), results.getString("venueName"), results.getString("capacity"), results.getString("venueTypeID"));
				itLabs.add(il);
			}
			results.close();
			return itLabs;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	//insert values into database

	//To insert one booking
	public static String insertOneBooking(Booking booking) {

		try {
			String query = "INSERT INTO booking(`bookingID`, `date`, `timeIn`, `timeOut`, `staffID`, `venueID`) VALUES "
					+ "(?,?,?,?,?,?)";

			//To prevent SQL Injection
			preparedStatement = connect.prepareStatement(query);
			preparedStatement.setString(1, booking.getBookingID());
			preparedStatement.setObject(2, booking.getDate());
			preparedStatement.setObject(3, booking.getTimeIn());
			preparedStatement.setObject(4, booking.getTimeOut());
			preparedStatement.setString(5, booking.getStaffID());
			preparedStatement.setString(6, booking.getVenueID());

			int rowAffected = preparedStatement.executeUpdate();
			System.out.println("Insert "+ booking.getBookingID() +" to booking table successful");
			System.out.println(String.format("Row affected %d", rowAffected));

			connect.commit();
			preparedStatement.close();

			return "";

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
	}

	//To insert one venue
	public static String insertOneVenue(LectureHall venue) {

		try {
			String query = "INSERT INTO venue(`venueID`, `venueName`, `capacity`, `venueTypeID`) VALUES "
					+ "(?,?,?,?)";

			//To prevent SQL Injection
			preparedStatement = connect.prepareStatement(query);
			preparedStatement.setString(1, venue.getVenueID());
			preparedStatement.setString(2, venue.getVenueName());
			preparedStatement.setString(3, venue.getCapacity());
			preparedStatement.setString(4, venue.getVenueTypeID());

			int rowAffected = preparedStatement.executeUpdate();
			System.out.println("Insert "+ venue.getVenueName() + " to venue table successful");
			System.out.println(String.format("Row affected %d", rowAffected));

			connect.commit();
			preparedStatement.close();

			return "";

		}
		catch (SQLException e) {
			e.printStackTrace();
			return e.getMessage();
		}
		catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
	}

	//update
	//To update one venue
	public static String updateOneVenue(LectureHall venue) {

		try {
				String query = "update venue set venueName = ?, capacity = ?, venueTypeID = ?"
						+ "where venue.venueID = ?";

				preparedStatement = connect.prepareStatement(query);
				preparedStatement.setString(1,venue.getVenueName());
				preparedStatement.setString(2, venue.getCapacity());
				preparedStatement.setString(3, venue.getVenueTypeID());
				preparedStatement.setString(4,venue.getVenueID());

				int rowAffected = preparedStatement.executeUpdate();

				connect.commit();
				preparedStatement.close();

				System.out.println("Successfully updated a record from venue table.");
				System.out.println(String.format("Row affected %d", rowAffected));

				return "";

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}

	}

	//delete
	//To delete one booking record
	public static String deleteBooking(Booking bookingID) {

			try {
				String query = "delete from booking where bookingID = ?";

				preparedStatement = connect.prepareStatement(query);
				preparedStatement.setString(1, bookingID.getBookingID());

				int rowAffected = preparedStatement.executeUpdate();
				System.out.println("Successfully deleted a record from booking table.");
				System.out.println(String.format("Row affected %d", rowAffected));

				connect.commit();
				preparedStatement.close();
				return "";

			} catch (Exception e) {
				e.printStackTrace();
				return e.getMessage();
			}
	}

	//To delete one venue
	public static String deleteVenue(LectureHall venue) {

			try {
				String query = "delete from venue where venueID = ?";

				preparedStatement = connect.prepareStatement(query);
				//preparedStatement.setString(1, venue.getVenueID());
				preparedStatement.setString(1, venue.getVenueID());

				int rowAffected = preparedStatement.executeUpdate();
				System.out.println("Successfully deleted a record from venue table.");
				System.out.println(String.format("Row affected %d", rowAffected));

				connect.commit();
				preparedStatement.close();
				return "";

			}
			catch (SQLIntegrityConstraintViolationException e) {
				return "Venue " + venue.getVenueID() + " is booked. Please remove booking first.";
			}

			catch (Exception e1) {
				e1.printStackTrace();
				return e1.getMessage();
			}

	}
}
