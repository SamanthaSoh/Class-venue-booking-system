package cvb_objects;

public class LectureHall extends VenueType{

	private String venueID, venueName, capacity, venueTypeID;

	public LectureHall() {}

	public LectureHall (String venueID, String venueName, String capacity, String venueTypeID) {
		super();
		this.venueID = venueID;
		this.venueName = venueName;
		this.capacity = capacity;
		this.venueTypeID = venueTypeID;
	}

	//setter methods
	public void setVenueID(String venueID) {
		this.venueID = venueID;
	}

	public void setVenueName(String venueName) {
		this.venueName = venueName;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public void setVenueTypeID() {
		super.setVenueTypeID("VT001");
	}

	//getter methods
	public String getVenueID() {
		return venueID;
	}

	public String getVenueName() {
		return venueName;
	}

	public String getCapacity() {
		return capacity;
	}

	@Override
	public String getVenueTypeID() {
		return venueTypeID;
	}

}
