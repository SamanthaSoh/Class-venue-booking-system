package gui;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cvb_objects.Booking;
import cvb_objects.V_StaffBooking;
import database.AccessDatabase;
import utils.UserUtils;


public class PanelRecords extends AccessDatabase {
	
	JPanel panelRecords;
	private static JTable tblBookingInfo;
	private static DefaultTableModel bookingTableModel;
	String staffID = UserUtils.getStaffID();
	static LocalDate date;
	final LocalDate today = LocalDate.now();
	private LocalTime timeIn, timeOut;
	private String venueID, bookingID;

	public PanelRecords() {
		
		panelRecords = new JPanel();
		panelRecords.setBounds(0,0, 454,396);
		panelRecords.setLayout(null);

		JLabel lblPanelRecords = new JLabel("BOOKING RECORDS");
		lblPanelRecords.setFont(new Font("Arial", Font.BOLD, 14));
		lblPanelRecords.setBounds(10, 11, 361, 36);
		panelRecords.add(lblPanelRecords);

		panelRecords.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentShown(ComponentEvent e) {
				try {
					showBooking(staffID);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});

		tblBookingInfo = new JTable() {
			@Override
			public boolean isCellEditable(int data, int columns) {
				return false;
			}
		};

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 46, 406, 172);
		panelRecords.add(scrollPane);
		scrollPane.setViewportView(tblBookingInfo);

		//cancel booking function
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				if (tblBookingInfo.getSelectedRow() < 0) {
					JOptionPane.showMessageDialog(new JFrame(), "Please select a booking record to cancel", "No booking record selected", JOptionPane.WARNING_MESSAGE);
					return;
				}

				String bookingID = tblBookingInfo.getValueAt(tblBookingInfo.getSelectedRow(), 0).toString();
				String tableDate = tblBookingInfo.getValueAt(tblBookingInfo.getSelectedRow(), 1).toString();
				LocalDate date = LocalDate.parse(tableDate);
				int confirmDeletetion = JOptionPane.showConfirmDialog(null, "Are you sure you want to cancel booking?",
						"Warning", JOptionPane.YES_NO_OPTION);
				if (confirmDeletetion != JOptionPane.YES_OPTION) {
					return;
				}

				Booking booking = new Booking(bookingID, date, timeIn, timeOut, staffID, venueID);
				int checkDate = date.compareTo(today);
				if(checkDate < 0) {
					JOptionPane.showMessageDialog(new JFrame(), "You are only allowed to cancel bookings for dates after " + today, "Action not allowed", JOptionPane.WARNING_MESSAGE);
				}
				else {
					String error = deleteBooking(booking);
					int getSelectedRowForDeletion = tblBookingInfo.getSelectedRow();
					if (tblBookingInfo.getSelectedRow() >= 0) {
						bookingTableModel.removeRow(getSelectedRowForDeletion);
					}
					if (!error.isEmpty()) {
						JOptionPane.showMessageDialog(new JFrame(), "Error : " + error);
						return;
					}
				}

				try {
					showBooking(staffID);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnCancel.setFont(new Font("Arial", Font.PLAIN, 14));
		btnCancel.setBounds(303, 236, 89, 27);
		panelRecords.add(btnCancel);
	}

	static void showBooking(String staffID) throws Exception {

		String[] columnBooking = {"Booking ID", "Date", "Time in", "Time out", "Venue name" };
		bookingTableModel = new DefaultTableModel(columnBooking, 0);

		ArrayList<V_StaffBooking> booking;
		try {
			booking = getStaffBooking(staffID);

			for (V_StaffBooking element : booking) {
				String bookingID = element.getBookingID();
				LocalDate date = element.getDate();
				LocalTime timeIn = element.getTimeIn();
				LocalTime timeOut = element.getTimeOut();
				String venueName = element.getVenueName();

				String[] dataBooking = {bookingID, date.toString(), timeIn.toString(), timeOut.toString(), venueName};
				bookingTableModel.addRow(dataBooking);
				tblBookingInfo.setModel(bookingTableModel);
				tblBookingInfo.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
