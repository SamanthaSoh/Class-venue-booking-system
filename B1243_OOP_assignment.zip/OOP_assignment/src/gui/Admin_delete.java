package gui;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import cvb_objects.LectureHall;
import cvb_objects.V_VenueInfo;
import database.AccessDatabase;

public class Admin_delete extends AccessDatabase {
	
	JPanel panelAdminDelete;
	private String venueName, capacity, venueType;
	private JTextField txtVenueID;
	private static JTable tblVenueInfo;
	private static DefaultTableModel venueTableModel;

	public Admin_delete() {
		
		panelAdminDelete = new JPanel();
		panelAdminDelete.setBounds(0,0, 454,396);
		panelAdminDelete.setLayout(null);

		JLabel lblPanelDelete = new JLabel("Delete venue");
		lblPanelDelete.setFont(new Font("Arial", Font.BOLD, 14));
		lblPanelDelete.setBounds(10, 11, 361, 36);
		panelAdminDelete.add(lblPanelDelete);

		panelAdminDelete.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentShown(ComponentEvent e) {
				try {
					showVenues();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});

		tblVenueInfo = new JTable() {
			@Override
			public boolean isCellEditable(int data, int columns) {
				return false;
			}
		};

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 46, 434, 172);
		panelAdminDelete.add(scrollPane);
		scrollPane.setViewportView(tblVenueInfo);

		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (tblVenueInfo.getSelectedRow() < 0) {
					JOptionPane.showMessageDialog(new JFrame(), "Please select a venue to delete!", "No venue selected", JOptionPane.WARNING_MESSAGE);
					return;
				}

				String venueID = tblVenueInfo.getValueAt(tblVenueInfo.getSelectedRow(), 0).toString();
				int confirmDeletetion = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this venue?",
						"Confirmation", JOptionPane.YES_NO_OPTION);
				if (confirmDeletetion != JOptionPane.YES_OPTION) {
					return;
				}

				LectureHall venue = new LectureHall (venueID, venueName, capacity, venueType);
				String error = deleteVenue(venue);
				int getSelectedRowForDeletion = tblVenueInfo.getSelectedRow();

				if (!error.isEmpty()) {
					JOptionPane.showMessageDialog(new JFrame(), "Error : " + error);
					return;
				}

				if (tblVenueInfo.getSelectedRow() >= 0) {
					venueTableModel.removeRow(getSelectedRowForDeletion);
				}

				try {
					showVenues();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnDelete.setFont(new Font("Arial", Font.PLAIN, 14));
		btnDelete.setBounds(355, 242, 89, 27);
		panelAdminDelete.add(btnDelete);
	}

	void showVenues() throws Exception {

		String[] columnBooking = {"Venue ID", "Venue name", "Capacity", "Venue type" };
		venueTableModel = new DefaultTableModel(columnBooking, 0);

		ArrayList<V_VenueInfo> venue;
		try {
			venue = getAllVenues();

			for (V_VenueInfo element : venue) {
				String venueID = element.getVenueID();
				String venueName = element.getVenueName();
				String capacity = element.getCapacity();
				String venueType = element.getVenueType();

				String[] dataBooking = {venueID, venueName, capacity, venueType};
				venueTableModel.addRow(dataBooking);
				tblVenueInfo.setModel(venueTableModel);
				tblVenueInfo.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
