package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ConnectDatabase {

	private static Connection connect;
	private static Statement statement;
	private static ResultSet results;

	public ConnectDatabase() {}

	public ConnectDatabase(String username, String password) {
		String url = "jdbc:mysql://localhost:3306/classvenuebooking?useUnicode=true"
	    		+ "&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false"
	    		+ "&serverTimezone=UTC";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver is ready");
		} catch (Exception e) {
			System.out.println("Failed to load JDBS/ODBC driver");
			return;
		}

		try {
			connect = DriverManager.getConnection(url, username, password);
			connect.setAutoCommit(false);
			statement = connect.createStatement();
		} catch (SQLException exception) {
			 while (exception != null){
	                System.out.println ("SQLState:   " + exception.getSQLState()  );
	                System.out.println ("Message:    " + exception.getMessage()   );
	                System.out.println ("Error code: " + exception.getErrorCode() );
	                JOptionPane.showMessageDialog(new JFrame(), exception.getMessage() + "\n Please verify database connection");
	                exception = exception.getNextException ();
	                System.out.println ("");
	            }
		}
		catch (java.lang.Exception exception) {
			exception.printStackTrace();
		}
	}

	static Connection getConnection() {
		return connect;
	}

	static Statement getStatement() {
		return statement;
	}

	static ResultSet getResults() {
		return results;
	}

	public static void close() {
		try {
			if(results != null) {
				results.close();
			}

			if(statement != null) {
				statement.close();
			}

			if(connect != null) {
				connect.close();
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
