package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import cvb_objects.Staff;
import database.ConnectDatabase;

public class Menu extends JFrame {

	static Staff staff;
	String staffID;

	private JPanel contentPane, panelAdmin, panelContent, panelAdminMenu, panelLecMenu, panelLogout;
	JLabel lblLogo;

	private Image img_logo = new ImageIcon(Login.class.getResource("/college.png")).getImage().getScaledInstance(90,90,Image.SCALE_SMOOTH);
	private Image img_home = new ImageIcon(Login.class.getResource("/home.png")).getImage().getScaledInstance(30,30,Image.SCALE_SMOOTH);
	private Image img_add = new ImageIcon(Login.class.getResource("/add.png")).getImage().getScaledInstance(28,28,Image.SCALE_SMOOTH);
	private Image img_records = new ImageIcon(Login.class.getResource("/record.png")).getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH);
	private Image img_logout = new ImageIcon(Login.class.getResource("/log_out.png")).getImage().getScaledInstance(26,26,Image.SCALE_SMOOTH);

	private PanelHome panelHome;
	private PanelAdd panelAdd;
	private PanelRecords panelRecords;
	private Admin_add panelAdminAdd;
	private Admin_update panelAdminUpdate;
	private Admin_delete panelAdminDelete;

	public Menu() throws Exception {
		setBackground(new Color(128, 0, 0));
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setBounds(100, 100, 676, 418);
		setUndecorated(true);
		setLocationRelativeTo(null);

		contentPane = new JPanel();
		contentPane.setBackground(new Color(230, 230, 250));
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		//panels that will be switched
		panelHome = new PanelHome();
		panelAdd = new PanelAdd();
		panelRecords = new PanelRecords();
		panelAdminAdd = new Admin_add();
		panelAdminUpdate = new Admin_update();
		panelAdminDelete = new Admin_delete();

		//Admin side menu panel
		panelAdminMenu = new JPanel();
		panelAdminMenu.setBackground(new Color(25, 25, 112));
		panelAdminMenu.setBounds(0, 0, 180, 419);
		panelAdminMenu.setLayout(null);

		//Lecturer side menu panel
		panelLecMenu = new JPanel();
		panelLecMenu.setBackground(new Color(25, 25, 112));
		panelLecMenu.setBounds(0, 0, 180, 419);
		panelLecMenu.setLayout(null);

		//Logo in side menu panel
		lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setBounds(10, 22, 159, 99);
		lblLogo.setIcon(new ImageIcon(img_logo));

		//Home panel in lecturer side menu
		JPanel homePanel = new JPanel();
		homePanel.setBackground(new Color(176,224,230));
		homePanel.addMouseListener(new PanelButtonMouseAdapter(homePanel) {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(panelHome);
			}
		});
		homePanel.setBounds(0, 170, 180, 28);
		panelLecMenu.add(homePanel);
		homePanel.setLayout(null);

		JLabel lblHome = new JLabel("HOME");
		lblHome.setFont(new Font("Arial", Font.BOLD, 12));
		lblHome.setBounds(54, 0, 116, 28);
		homePanel.add(lblHome);

		JLabel lblHomeIcon = new JLabel("");
		lblHomeIcon.setHorizontalAlignment(SwingConstants.CENTER);
		lblHomeIcon.setBounds(0, 0, 46, 28);
		lblHomeIcon.setIcon(new ImageIcon(img_home));
		homePanel.add(lblHomeIcon);

		//Add booking panel in lecturer side menu
		JPanel panelAddBooking = new JPanel();
		panelAddBooking.setBackground(new Color(176,224,230));
		panelAddBooking.addMouseListener(new PanelButtonMouseAdapter(panelAddBooking) {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(panelAdd.panelAdd);
			}
		});
		panelAddBooking.setBounds(0, 209, 180, 28);
		panelLecMenu.add(panelAddBooking);
		panelAddBooking.setLayout(null);

		JLabel lblAddBooking = new JLabel("ADD BOOKING");
		lblAddBooking.setFont(new Font("Arial", Font.BOLD, 12));
		lblAddBooking.setBounds(50, 0, 123, 28);
		panelAddBooking.add(lblAddBooking);

		JLabel lblAddIcon = new JLabel("");
		lblAddIcon.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddIcon.setBounds(0, 0, 46, 28);
		lblAddIcon.setIcon(new ImageIcon(img_add));
		panelAddBooking.add(lblAddIcon);

		//Booking records panel in lecturer side menu
		JPanel panelBookingRecords = new JPanel();
		panelBookingRecords.setBorder(new EmptyBorder(0, 0, 0, 0));
		panelBookingRecords.setBackground(new Color(176,224,230));
		panelBookingRecords.addMouseListener(new PanelButtonMouseAdapter(panelBookingRecords) {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(panelRecords.panelRecords);
			}
		});
		panelBookingRecords.setBounds(0, 248, 180, 28);
		panelLecMenu.add(panelBookingRecords);
		panelBookingRecords.setLayout(null);

		JLabel lblBookingRecords = new JLabel("BOOKING RECORDS");
		lblBookingRecords.setForeground(new Color(0, 0, 0));
		lblBookingRecords.setFont(new Font("Arial", Font.BOLD, 12));
		lblBookingRecords.setBounds(50, 0, 123, 28);
		panelBookingRecords.add(lblBookingRecords);

		JLabel lblRecordsIcon = new JLabel("");
		lblRecordsIcon.setHorizontalAlignment(SwingConstants.CENTER);
		lblRecordsIcon.setBounds(0, 0, 46, 28);
		lblRecordsIcon.setIcon(new ImageIcon(img_records));
		panelBookingRecords.add(lblRecordsIcon);

		//Admin function: Add venue panel in admin side menu
		JPanel panelAddVenue = new JPanel();
		panelAddVenue.setBackground(new Color(176,224,230));
		panelAddVenue.addMouseListener(new PanelButtonMouseAdapter(panelAddVenue) {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(panelAdminAdd.panelAdminAdd);
			}
		});
		panelAddVenue.setBounds(0, 170, 180, 28);
		panelAdminMenu.add(panelAddVenue);
		panelAddVenue.setLayout(null);

		JLabel lblAddVenue = new JLabel("ADD VENUE");
		lblAddVenue.setFont(new Font("Arial", Font.BOLD, 12));
		lblAddVenue.setBounds(50, 0, 123, 28);
		panelAddVenue.add(lblAddVenue);

		//Admin function: Update venue panel in side menu
		JPanel panelUpdateVenue = new JPanel();
		panelUpdateVenue.setBorder(new EmptyBorder(0, 0, 0, 0));
		panelUpdateVenue.setBackground(new Color(176,224,230));
		panelUpdateVenue.addMouseListener(new PanelButtonMouseAdapter(panelUpdateVenue) {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(panelAdminUpdate.panelAdminUpdate);
			}
		});
		panelUpdateVenue.setBounds(0, 209, 180, 28);
		panelAdminMenu.add(panelUpdateVenue);
		panelUpdateVenue.setLayout(null);

		JLabel lblUpdateVenue = new JLabel("UPDATE VENUE");
		lblUpdateVenue.setForeground(new Color(0, 0, 0));
		lblUpdateVenue.setFont(new Font("Arial", Font.BOLD, 12));
		lblUpdateVenue.setBounds(50, 0, 123, 28);
		panelUpdateVenue.add(lblUpdateVenue);

		//Admin function: Delete venue panel in side menu
		JPanel panelDeleteVenue = new JPanel();
		panelDeleteVenue.setBorder(new EmptyBorder(0, 0, 0, 0));
		panelDeleteVenue.setBackground(new Color(176,224,230));
		panelDeleteVenue.addMouseListener(new PanelButtonMouseAdapter(panelDeleteVenue) {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(panelAdminDelete.panelAdminDelete);
			}
		});
		panelDeleteVenue.setBounds(0, 250, 180, 28);
		panelAdminMenu.add(panelDeleteVenue);
		panelDeleteVenue.setLayout(null);

		JLabel lblDeleteVenue = new JLabel("DELETE VENUE");
		lblDeleteVenue.setForeground(new Color(0, 0, 0));
		lblDeleteVenue.setFont(new Font("Arial", Font.BOLD, 12));
		lblDeleteVenue.setBounds(50, 0, 123, 28);
		panelDeleteVenue.add(lblDeleteVenue);

		//Logout panel in side menu
		panelLogout = new JPanel();
		panelLogout.setBackground(new Color(176,224,230));
		panelLogout.addMouseListener(new PanelButtonMouseAdapter(panelLogout) {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					if(JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Confirmation", JOptionPane.YES_NO_OPTION) == 0){
						Login login = new Login();
						login.loginFrame.setVisible(true);
						Menu.this.dispose();
					}
				}catch (Exception e1) {
					String msg = e1.getMessage();
					if (msg.isEmpty()) {
						JOptionPane.showMessageDialog(new JFrame(), "Something is null, check database connection");
					}
					else {
						JOptionPane.showMessageDialog(new JFrame(), e1.getMessage());
					}
					e1.printStackTrace();
				}
			}
		});
		panelLogout.setBounds(0, 287, 180, 28);

		panelLogout.setLayout(null);

		JLabel lblLogout = new JLabel("LOGOUT");
		lblLogout.setFont(new Font("Arial", Font.BOLD, 12));
		lblLogout.setBounds(50, 0, 123, 28);
		panelLogout.add(lblLogout);

		JLabel lblLogoutIcon = new JLabel("");
		lblLogoutIcon.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogoutIcon.setBounds(0, 0, 46, 28);
		lblLogoutIcon.setIcon(new ImageIcon(img_logout));
		panelLogout.add(lblLogoutIcon);

		//Exit label
		JLabel lblExit = new JLabel("X");
		lblExit.setHorizontalAlignment(SwingConstants.CENTER);
		lblExit.setForeground(Color.BLACK);
		lblExit.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
		lblExit.setBounds(646,11,20,20);
		lblExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				closeProgram();
				Menu.this.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblExit.setForeground(Color.RED);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblExit.setForeground(Color.BLACK);
			}
		});
		contentPane.add(lblExit);

		//Panel for lecturers
		panelContent = new JPanel();
		panelContent.setBackground(new Color(255, 255, 255));
		panelContent.setBounds(190, 11, 454, 396);
		panelContent.setLayout(null);
		panelContent.add(panelHome);
		panelContent.add(panelAdd.panelAdd);
		panelContent.add(panelRecords.panelRecords);

		//Panel for lecturers
		panelAdmin = new JPanel();
		panelAdmin.setBackground(new Color(255, 255, 255));
		panelAdmin.setBounds(190, 11, 454, 396);
		panelAdmin.setLayout(null);
		panelAdmin.add(panelAdminAdd.panelAdminAdd);
		panelAdmin.add(panelAdminUpdate.panelAdminUpdate);
		panelAdmin.add(panelAdminDelete.panelAdminDelete);
	}

	public void menuClicked(JPanel panel) {
		panelHome.setVisible(false);
		panelAdd.panelAdd.setVisible(false);
		panelRecords.panelRecords.setVisible(false);
		panelAdminAdd.panelAdminAdd.setVisible(false);
		panelAdminUpdate.panelAdminUpdate.setVisible(false);
		panelAdminDelete.panelAdminDelete.setVisible(false);

		panel.setVisible(true);
	}

	private class PanelButtonMouseAdapter extends MouseAdapter{

		JPanel panel;
		public PanelButtonMouseAdapter(JPanel panel) {
			this.panel = panel;
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(255,255,255));
		}

		@Override
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(176,224,230));
		}

		@Override
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(175,238,238));
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(176,196,222));
		}
	}

	public void setUserView(Staff newStaff) {
		staff = newStaff;

		try {
			if (staff.getJobTitleID().equals("J001")) {
				contentPane.add(panelAdmin);
				panelAdminMenu.add(lblLogo);
				contentPane.add(panelAdminMenu);
				panelAdminMenu.add(panelLogout);
				menuClicked(panelAdminAdd.panelAdminAdd);
			}
			else {
				contentPane.add(panelContent);
				panelLecMenu.add(lblLogo);
				contentPane.add(panelLecMenu);
				panelLecMenu.add(panelLogout);
				menuClicked(panelHome);
			}
		} catch(Exception e1) {
			String msg = e1.getMessage();
			if (msg.isEmpty()) {
				JOptionPane.showMessageDialog(new JFrame(), "Something is null, check database connection");
			}
			else {
				JOptionPane.showMessageDialog(new JFrame(), e1.getMessage());
			}
			e1.printStackTrace();
		}

		staffID = staff.getStaffID();
	}

	int closeProgram() {
		int exit = JOptionPane.showConfirmDialog(null, "Are you sure you want to close this application?", "Confirmation", JOptionPane.YES_NO_OPTION);
		if (exit == JOptionPane.YES_OPTION) {
			ConnectDatabase.close();
			System.out.println("Database connection is closed");
			System.exit(0);
		}
		else {
			System.exit(1);
		}
		return 0;
	}
}
