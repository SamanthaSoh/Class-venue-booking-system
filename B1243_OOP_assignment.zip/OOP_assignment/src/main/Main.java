package main;

import database.AccessDatabase;
import database.ConnectDatabase;
import gui.Login;

public class Main {

	public static void main(String[] args) {

		try {
			ConnectDatabase cdb = new ConnectDatabase("root", "");
			AccessDatabase adb = new AccessDatabase();
			Login login = new Login();
			login.loginFrame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
