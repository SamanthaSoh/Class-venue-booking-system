package cvb_objects;

import java.time.LocalDate;
import java.time.LocalTime;

public class V_StaffBooking {

		private String bookingID, staffID, venueID, venueName;
		private LocalDate date;
		private LocalTime timeIn, timeOut;

		public V_StaffBooking() {}

		public V_StaffBooking(String bookingID, String staffID, LocalDate date,  LocalTime timeIn,  LocalTime timeOut, String venueID, String venueName) {
			this.bookingID = bookingID;
			this.staffID = staffID;
			this.date = date;
			this.timeIn = timeIn;
			this.timeOut = timeOut;
			this.venueID = venueID;
			this.venueName = venueName;
		}

		public String getBookingID() {
			return bookingID;
		}

		public String getStaffID() {
			return staffID;
		}

		public LocalDate getDate() {
			return date;
		}

		public LocalTime getTimeIn() {
			return timeIn;
		}

		public LocalTime getTimeOut() {
			return timeOut;
		}

		public String getVenueID() {
			return venueID;
		}

		public String getVenueName() {
			return venueName;
		}

}
