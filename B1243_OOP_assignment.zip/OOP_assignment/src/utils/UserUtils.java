package utils;

public class UserUtils {

	static String staffID;

	public UserUtils() {

	}

	public static void setStaffID(String staffID) {
		UserUtils.staffID = staffID;
	}

	public static String getStaffID() {
		return staffID;
	}


}
