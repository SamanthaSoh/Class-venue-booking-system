package gui;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cvb_objects.LectureHall;
import cvb_objects.V_VenueInfo;
import database.AccessDatabase;

public class Admin_update extends AccessDatabase {
	
	JPanel panelAdminUpdate;
	private JLabel lblPanelUpdate;
	private JLabel lblVenueID;
	private JLabel lblNewVenueName;
	private JLabel lblNewVenueCapacity;
	private JButton btnUpdate;
	private JTextField txtVenueID;
	private JTextField txtVenueName;
	private JTextField txtVenueCapacity;
	private static V_VenueInfo selectedVenue = null;

	private String venueTypeID;


	public Admin_update() {
		
		panelAdminUpdate = new JPanel();
		panelAdminUpdate.setBounds(0,0, 454,396);
		panelAdminUpdate.setLayout(null);

		lblPanelUpdate = new JLabel("Update venue");
		lblPanelUpdate.setFont(new Font("Arial", Font.BOLD, 14));
		lblPanelUpdate.setBounds(10, 11, 361, 36);
		panelAdminUpdate.add(lblPanelUpdate);

		lblVenueID = new JLabel("Enter venue ID:");
		lblVenueID.setFont(new Font("Arial", Font.PLAIN, 14));
		lblVenueID.setBounds(10, 64, 102, 27);
		panelAdminUpdate.add(lblVenueID);

		txtVenueID = new JTextField();
		txtVenueID.setBounds(122, 64, 120, 27);
		panelAdminUpdate.add(txtVenueID);
		txtVenueID.setColumns(10);

		lblNewVenueName = new JLabel("New venue name:");
		lblNewVenueName.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewVenueName.setBounds(10, 112, 112, 27);

		txtVenueName = new JTextField();
		txtVenueName.setColumns(10);
		txtVenueName.setBounds(173, 113, 143, 27);

		lblNewVenueCapacity = new JLabel("New venue capacity:");
		lblNewVenueCapacity.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewVenueCapacity.setBounds(10, 150, 136, 27);

		txtVenueCapacity = new JTextField();
		txtVenueCapacity.setColumns(10);
		txtVenueCapacity.setBounds(173, 154, 143, 27);

		panelAdminUpdate.add(lblNewVenueName);
		panelAdminUpdate.add(txtVenueName);
		panelAdminUpdate.add(lblNewVenueCapacity);
		panelAdminUpdate.add(txtVenueCapacity);

		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					selectedVenue = null;
					ArrayList<V_VenueInfo> venues = getAllVenues();
					for (V_VenueInfo venue : venues) {
						String DBVenueID = venue.getVenueID();
						String venueIDInput = txtVenueID.getText();

						if (DBVenueID.equals(venueIDInput)) {
							selectedVenue = venue;
							break;
						}
					}
					//if not empty
					if (selectedVenue != null) {
						System.out.println("Venue ID found succesfully");
						JOptionPane.showMessageDialog(new JFrame(), "Venue ID found.");
						txtVenueName.setText(selectedVenue.getVenueName());
						txtVenueCapacity.setText(selectedVenue.getCapacity());
						venueTypeID = selectedVenue.getVenueTypeID();
					}
					else {
						JOptionPane.showMessageDialog(new JFrame(), "Venue ID entered not found.","Venue ID not found", JOptionPane.WARNING_MESSAGE);
						return;
					}
				} catch (Exception e1){
					String msg = e1.getMessage();
					if (msg.isEmpty()) {
						JOptionPane.showMessageDialog(new JFrame(), "Something is null, check database connection");
					}
					else {
						JOptionPane.showMessageDialog(new JFrame(), e1.getMessage());
					}
					e1.printStackTrace();
				}
			}
		});
		btnSearch.setFont(new Font("Arial", Font.PLAIN, 14));
		btnSearch.setBounds(271, 64, 89, 27);
		panelAdminUpdate.add(btnSearch);

		btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				try {
					selectedVenue = null;
					ArrayList<V_VenueInfo> venues = getAllVenues();
					for (V_VenueInfo venue : venues) {
						String DBVenueID = venue.getVenueID();
						String venueIDInput = txtVenueID.getText();

						if (DBVenueID.equals(venueIDInput)) {
							selectedVenue = venue;
							break;
						}
					}
					//if not empty
					if (selectedVenue != null) {

						LectureHall newVenue = new LectureHall(txtVenueID.getText(), txtVenueName.getText(), txtVenueCapacity.getText(), venueTypeID);
						String error = updateOneVenue(newVenue);
						if (!error.isEmpty()) {
							JOptionPane.showMessageDialog(new JFrame(), error + "\nPlease contact admin server");
						} else {
							JOptionPane.showMessageDialog(new JFrame(), "Update venue successful");
							return;
						}
					}
					else {
						JOptionPane.showMessageDialog(new JFrame(), "Update venue unsuccessful.\nVenue ID incorrect", "Incorrect venue ID", JOptionPane.WARNING_MESSAGE);
						return;
					}
				} catch (Exception e1){
					String msg = e1.getMessage();
					if (msg.isEmpty()) {
						JOptionPane.showMessageDialog(new JFrame(), "Something is null, check database connection");
					} else {
						JOptionPane.showMessageDialog(new JFrame(), e1.getMessage());
					}
					e1.printStackTrace();
				}

				if(txtVenueID.getText().isBlank()){
					JOptionPane.showMessageDialog(new JFrame(), "Please enter venue ID", "Empty field", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if (txtVenueName.getText().isBlank()) {
					JOptionPane.showMessageDialog(new JFrame(), "Please enter venue name", "Empty field", JOptionPane.WARNING_MESSAGE);
					return;
				}
				if(txtVenueCapacity.getText().isBlank()) {
					JOptionPane.showMessageDialog(new JFrame(), "Please enter venue capacity", "Empty field", JOptionPane.WARNING_MESSAGE);
					return;
				}
			}
		});
		btnUpdate.setFont(new Font("Arial", Font.PLAIN, 14));
		btnUpdate.setBounds(271, 277, 89, 27);
		panelAdminUpdate.add(btnUpdate);
	}
}
